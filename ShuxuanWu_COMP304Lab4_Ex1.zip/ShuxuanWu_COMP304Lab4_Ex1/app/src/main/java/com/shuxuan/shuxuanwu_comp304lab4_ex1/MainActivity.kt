package com.shuxuan.shuxuanwu_comp304lab4_ex1

import android.os.Bundle
import android.widget.Toast
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts

import com.shuxuan.shuxuanwu_comp304lab4_ex1.ui.screens.MapScreen
import android.Manifest
import android.content.pm.PackageManager
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.viewModels
import androidx.compose.runtime.*
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.google.android.gms.maps.model.LatLng
import com.shuxuan.shuxuanwu_comp304lab4_ex1.viewmodel.LocationViewModel
import com.shuxuan.shuxuanwu_comp304lab4_ex1.geofencing.GeofenceHelper
import androidx.compose.runtime.collectAsState
import com.shuxuan.shuxuanwu_comp304lab4_ex1.ui.theme.ShuxuanWu_COMP304Lab4_Ex1Theme
import com.shuxuan.shuxuanwu_comp304lab4_ex1.worker.LocationHelper

class MainActivity :ComponentActivity() {
    // ViewModel for location management
    private val viewModel: LocationViewModel by viewModels {
        object : ViewModelProvider.Factory {
            override fun <T : ViewModel> create(modelClass: Class<T>): T {
                return LocationViewModel(application) as T
            }
        }
    }

    // Permission launcher to request foreground location permission
    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            Log.d("MainActivity", "Foreground location permission granted")
            // Permission has already been granted, proceed with accessing location
            onLocationPermissionGranted()
        } else {
            Log.d("MainActivity", "Foreground location permission not granted")
            Toast.makeText(this, "Foreground location permission not granted", Toast.LENGTH_SHORT).show()
        }
    }

    private lateinit var geofenceHelper: GeofenceHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Initialize GeofenceHelper
        geofenceHelper = GeofenceHelper(this)

        // Initial permission check
        checkLocationPermissions()

        setContent {
            ShuxuanWu_COMP304Lab4_Ex1Theme {
                // Observing state for user location and permission status
                val locationPermissionGranted by viewModel.locationPermissionGranted.collectAsState(initial = false)
                val userLocation by viewModel.userLocation.collectAsState(initial = LatLng(43.6532, -79.3832)) // Default to Toronto

                MapScreen(userLocation = userLocation, locationPermissionGranted = locationPermissionGranted)

                if (locationPermissionGranted) {
                    // Once location is granted, add a geofence around the user's location
                    addGeofence(userLocation, 100f)
                }
            }
        }

    }

    // Function to check and request location permissions
    private fun checkLocationPermissions() {
        val permissionFineLocation = Manifest.permission.ACCESS_FINE_LOCATION
        if (ContextCompat.checkSelfPermission(this, permissionFineLocation)
            != PackageManager.PERMISSION_GRANTED
        ) {
            // Permission is not granted, request it
            permissionLauncher.launch(permissionFineLocation)
        } else {
            // Permission has already been granted, proceed with accessing location
            onLocationPermissionGranted()
        }
    }
    private fun onLocationPermissionGranted() {
        viewModel.setLocationPermissionGranted(true)
        viewModel.startLocationUpdates()

        // Setup location-related features
        setupLocationFeatures()

        // Schedule location updates using the helper function
        LocationHelper.scheduleLocationUpdates(this)
    }

    // Function to add a geofence using GeofenceHelper
    private fun addGeofence(latLng: LatLng, radius: Float) {
        // Check if permission is granted
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            // Generate unique ID for geofence (for demo purposes, we use "MY_GEOFENCE")
            val geofenceId = "MY_GEOFENCE"

            // Use GeofenceHelper to add a geofence
            geofenceHelper.addGeofence(geofenceId, latLng, radius)
        } else {
            Toast.makeText(this, "Location permission not granted for geofencing", Toast.LENGTH_SHORT).show()
        }
    }


    // Setup other location-related features
    private fun setupLocationFeatures() {
        viewModel.startLocationUpdates()
    }

    override fun onDestroy() {
        super.onDestroy()
        viewModel.stopLocationUpdates()
    }
}
