package com.shuxuan.shuxuanwu_comp304lab4_ex1.ui.screens

import android.util.Log
import android.widget.Toast
import androidx.compose.runtime.Composable
import com.google.android.gms.maps.model.LatLng
import com.google.maps.android.compose.GoogleMap
import com.google.maps.android.compose.MapProperties
import com.google.maps.android.compose.MapUiSettings
import com.google.maps.android.compose.rememberCameraPositionState
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import com.google.android.gms.maps.model.CameraPosition
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import com.google.maps.android.compose.Polyline
import com.google.maps.android.compose.MarkerState
import com.google.maps.android.compose.Marker

@Composable
fun MapScreen(
    userLocation: LatLng,
    locationPermissionGranted: Boolean
) {
    val context = LocalContext.current
    val cameraPositionState = rememberCameraPositionState {
        position = CameraPosition.fromLatLngZoom(userLocation, 15f)
    }

    // Lists to hold markers and polylines
    val markers = remember { mutableStateListOf<LatLng>() }
    val polylinePoints = remember { mutableStateListOf<LatLng>() }

    GoogleMap(
        modifier = Modifier.fillMaxSize(),
        cameraPositionState = cameraPositionState,
        uiSettings = MapUiSettings(
            myLocationButtonEnabled = locationPermissionGranted,
        ),
        properties = MapProperties(
            isMyLocationEnabled = locationPermissionGranted,
        ),
        onMapClick = { latLng ->
            // Add a marker at the clicked location
            markers.add(latLng)
        },
        onMapLongClick = { latLng ->
            // Add a point to the polyline on long press
            polylinePoints.add(latLng)
            Log.d("MapScreen", "Added polyline point: $latLng")

            Toast.makeText(context, "Point added for polyline: $latLng", Toast.LENGTH_SHORT).show()
        }
    ) {
        // Draw markers on the map
        for (marker in markers) {
            Marker(
                state = MarkerState(position = marker),
                title = "Marker at ${marker.latitude}, ${marker.longitude}"
            )
        }

        // Draw polylines if there are enough points
        if (polylinePoints.size > 1) {
            Polyline(
                points = polylinePoints.toList(),
                color = Color.Blue,
                width = 5f
            )
        }
    }
}

